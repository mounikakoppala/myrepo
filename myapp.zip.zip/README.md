> **ARCHIVED**: This repository has been relocated to the [samples](https://github.com/buildpack/samples/) repo.

## sample-java-app
